#include <iostream>
#include <chrono>
#include <limits>

#include "Board.h"
#include "AlphaBeta.h"
#include "Statistics.h"

using namespace std;
using namespace std::chrono;

const int DEPTH = 5;

// ================= PLAYER INPUT =================
int getPlayerMove(Board& board)
{
    int col;

    while (true)
    {
        cout << "Enter column (0-6): ";
        cin >> col;

        if (cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a number.\n";
            continue;
        }

        if (col < 0 || col >= COLS)
        {
            cout << "Column must be between 0 and 6.\n";
            continue;
        }

        if (!board.isValidMove(col))
        {
            cout << "This column is full.\n";
            continue;
        }

        return col;
    }
}

// ================= GAME =================
void playerVsAI()
{
    Board board;
    Statistics stats;

    int playerPiece = 1;
    int aiPiece = 2;

    AlphaBeta ai(aiPiece, playerPiece);

    cout << "\nYou are X (1)\n";
    cout << "AI is O (2)\n\n";

    // ================= START CHOICE =================
    int turn;
    cout << "Who starts?\n";
    cout << "1. Player\n";
    cout << "2. AI\n";
    cout << "Choose: ";
    cin >> turn;

    bool isPlayerTurn = (turn == 1);

    board.printBoard();

    while (true)
    {
        // ================= AI TURN =================
        if (!isPlayerTurn)
        {
            cout << "AI is thinking...\n";

            auto start = high_resolution_clock::now();
            int aiCol = ai.getBestMove(board, DEPTH, stats);
            auto end = high_resolution_clock::now();

            long long timeMs =
                duration_cast<milliseconds>(end - start).count();

            int aiRow = board.getNextOpenRow(aiCol);
            board.dropPiece(aiRow, aiCol, aiPiece);

            cout << "AI chose column " << aiCol << "\n";
            board.printBoard();

            if (board.checkWin(aiPiece))
            {
                cout << "AI wins!\n";
                return;
            }

            if (board.isBoardFull())
            {
                cout << "Draw!\n";
                return;
            }
        }

        // ================= PLAYER TURN =================
        else
        {
            int playerCol = getPlayerMove(board);
            int playerRow = board.getNextOpenRow(playerCol);
            board.dropPiece(playerRow, playerCol, playerPiece);

            board.printBoard();

            if (board.checkWin(playerPiece))
            {
                cout << "Player wins!\n";
                return;
            }

            if (board.isBoardFull())
            {
                cout << "Draw!\n";
                return;
            }
        }

        // switch turns
        isPlayerTurn = !isPlayerTurn;
    }
}

// ================= MAIN MENU =================
int main()
{
    int choice;

    while (true)
    {
        cout << "\n========== CONNECT FOUR ==========\n";
        cout << "1. Start Game\n";
        cout << "2. Exit\n";
        cout << "Choose: ";

        cin >> choice;

        if (cin.fail())
        {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input.\n";
            continue;
        }

        if (choice == 1)
        {
            playerVsAI();
        }
        else if (choice == 2)
        {
            cout << "Goodbye!\n";
            break;
        }
        else
        {
            cout << "Invalid choice.\n";
        }
    }

    return 0;
}
